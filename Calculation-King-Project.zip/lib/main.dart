import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const CalculationKing());

const navy = Color(0xFF172746);
const violet = Color(0xFF6D4CC3);
const teal = Color(0xFF16A6A0);
const gold = Color(0xFFE2B44A);

class CalculationKing extends StatelessWidget {
  const CalculationKing({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Calculation King',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: violet, brightness: Brightness.light),
      scaffoldBackgroundColor: const Color(0xFFF5F6FB),
      cardTheme: CardThemeData(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  final quotes = [
    'Your dream deserves your daily effort.',
    'Beat your previous calculation speed.',
    'Small calculations. Bigger ambitions.',
    'Make every second count.',
    'Your selection starts with today’s practice.',
  ];
  int quote = 0;
  final items = const [
    ('Tables', '1 to 50', Icons.close_rounded),
    ('Squares', '1 to 100', Icons.grid_4x4_rounded),
    ('Cubes', '1 to 50', Icons.view_in_ar_rounded),
    ('Percentage to Fraction', 'Convert & revise', Icons.percent_rounded),
    ('Fraction to Percentage', 'Convert & revise', Icons.pie_chart_outline_rounded),
    ('Exercise', '5 calculation types', Icons.bolt_rounded),
  ];
  @override
  void initState() { super.initState(); Timer.periodic(const Duration(seconds: 5), (t) { if (mounted) setState(() => quote = (quote + 1) % quotes.length); else t.cancel(); }); }
  void open(String title) => Navigator.push(context, MaterialPageRoute(builder: (_) => title == 'View My Progress' ? const ProgressPage() : LearningPage(title: title)));
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [navy, Color(0xFF493477)]),
        borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('CALCULATION KING', style: TextStyle(color: gold, fontWeight: FontWeight.w800, letterSpacing: 2)),
          const SizedBox(height: 16),
          const Text('HEY, CHAMPIONS! 🔥', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          AnimatedSwitcher(duration: const Duration(milliseconds: 350), child: Text(quotes[quote], key: ValueKey(quote), style: const TextStyle(color: Colors.white, fontSize: 15))),
        ])),
      const SizedBox(height: 22),
      const Text('Choose your practice', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.35),
        itemBuilder: (_, i) { final x = items[i]; return InkWell(onTap: () => open(x.$1), borderRadius: BorderRadius.circular(18), child: Container(
          padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE5E6EF))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(x.$3, color: i.isEven ? violet : teal, size: 28), const SizedBox(height: 9),
            Text(x.$1, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            const SizedBox(height: 3), Text(x.$2, style: const TextStyle(color: Colors.black54, fontSize: 11)),
          ]))); }),
      const SizedBox(height: 14),
      FilledButton.tonalIcon(onPressed: () => open('View My Progress'), icon: const Icon(Icons.calendar_month), label: const Padding(padding: EdgeInsets.symmetric(vertical: 15), child: Text('View My Progress', style: TextStyle(fontWeight: FontWeight.bold)))),
      const SizedBox(height: 24),
      const Center(child: Text('CRAFTED & DEVELOPED BY VIKSO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1, color: violet))),
    ])),
  );
}

class LearningPage extends StatefulWidget {
  final String title;
  const LearningPage({super.key, required this.title});
  @override State<LearningPage> createState() => _LearningPageState();
}
class _LearningPageState extends State<LearningPage> {
  int selected = 1;
  String mode = 'Learn';
  @override
  Widget build(BuildContext context) {
    final isExercise = widget.title == 'Exercise';
    final max = widget.title == 'Tables' || widget.title == 'Cubes' ? 50 : 100;
    return Scaffold(appBar: AppBar(title: Text(widget.title)), body: ListView(padding: const EdgeInsets.all(18), children: [
      if (isExercise) ...[
        const Text('Choose calculation type', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        for (final op in ['Addition','Subtraction','Multiplication','Division','Mixed'])
          ListTile(title: Text(op), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExercisePage(operation: op)))),
      ] else ...[
        Text(widget.title == 'Percentage to Fraction' || widget.title == 'Fraction to Percentage' ? 'Common conversions' : 'Choose a number', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        if (widget.title == 'Percentage to Fraction' || widget.title == 'Fraction to Percentage')
          ...List.generate(9, (i) { final p = [10,12.5,20,25,30,40,50,60,75][i]; final f = ['1/10','1/8','1/5','1/4','3/10','2/5','1/2','3/5','3/4'][i]; return Card(child: ListTile(title: Text(widget.title == 'Percentage to Fraction' ? '$p%  =  $f' : '$f  =  $p%'))); })
        else
          Wrap(spacing: 8, runSpacing: 8, children: List.generate(max, (i) => ChoiceChip(label: Text('${i+1}'), selected: selected == i+1, onSelected: (_) => setState(() => selected = i+1)))),
        const SizedBox(height: 18),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'Learn', label: Text('Learn')), ButtonSegment(value: 'Practice', label: Text('Practice'))], selected: {mode}, onSelectionChanged: (s) => setState(() => mode = s.first)),
        const SizedBox(height: 18),
        if (mode == 'Learn') _learnContent() else FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => QuizPage(topic: widget.title, number: selected))), child: const Text('Start 10-question practice')),
      ]
    ]));
  }
  Widget _learnContent() {
    if (widget.title == 'Percentage to Fraction' || widget.title == 'Fraction to Percentage') {
      return const Text('Review the common conversions above, then select Practice when ready.');
    }
    final rows = List.generate(10, (i) {
      final multiplier = i + 1;
      if (widget.title == 'Tables') return '$selected × $multiplier = ${selected * multiplier}';
      if (widget.title == 'Squares') return '$selected² = ${selected * selected}';
      return '$selected³ = ${selected * selected * selected}';
    });
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: rows.map((row) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Text(row, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          )).toList(),
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  final String topic; final int number;
  const QuizPage({super.key, required this.topic, required this.number});
  @override State<QuizPage> createState() => _QuizPageState();
}
class _QuizPageState extends State<QuizPage> {
  final random = Random();
  int index = 0, correct = 0, wrong = 0;
  final List<Map<String,dynamic>> answers = [];
  late DateTime started;
  int? chosen;
  late List<int> options;
  late int answer;
  Timer? tick;
  int seconds = 0;
  @override void initState() { super.initState(); started = DateTime.now(); _makeQuestion(); tick = Timer.periodic(const Duration(seconds: 1), (_) { if(mounted) setState(() => seconds++); }); }
  void _makeQuestion() {
    chosen = null;
    int a = widget.number, b = index + 1;
    if (widget.topic == 'Tables') answer = a*b;
    else if (widget.topic == 'Squares') { a = random.nextInt(100)+1; answer = a*a; }
    else if (widget.topic == 'Cubes') { a = random.nextInt(50)+1; answer = a*a*a; }
    else { a = [10,20,25,50,75][random.nextInt(5)]; answer = a; }
    final distractors = <int>{answer};
    while(distractors.length < 4) { final delta = max(1, (answer.abs()*0.2).round()); distractors.add(max(0, answer + random.nextInt(delta*2+1)-delta)); }
    options = distractors.toList()..shuffle();
    currentA = a; currentB = b;
  }
  int currentA = 1, currentB = 1;
  String get question => widget.topic == 'Tables' ? '$currentA × $currentB = ?' : widget.topic == 'Squares' ? '$currentA² = ?' : widget.topic == 'Cubes' ? '$currentA³ = ?' : '$currentA% as a fraction (numerator/denominator value simplified not tested)';
  void choose(int value) { if(chosen != null) return; setState(() { chosen = value; if(value == answer) correct++; else wrong++; answers.add({'q': question, 'your': value, 'answer': answer, 'ok': value == answer}); }); }
  Future<void> finish() async {
    tick?.cancel();
    final prefs = await SharedPreferences.getInstance();
    final history = prefs.getStringList('history') ?? [];
    history.add(jsonEncode({'date': DateTime.now().toIso8601String(),'topic':widget.topic,'correct':correct,'wrong':wrong,'total':10,'seconds':seconds,'details':answers}));
    await prefs.setStringList('history', history);
    if(mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ResultPage(topic: widget.topic, correct: correct, wrong: wrong, seconds: seconds, details: answers)));
  }
  @override void dispose(){tick?.cancel();super.dispose();}
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text('${widget.topic} Practice'), actions:[Padding(padding: const EdgeInsets.all(14), child: Text('⏱ ${seconds}s'))]), body: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children:[
    LinearProgressIndicator(value:(index+1)/10), const SizedBox(height:20),
    Text('Question ${index+1} of 10',style:const TextStyle(color:Colors.black54)),
    const SizedBox(height:22), Text(question,style:const TextStyle(fontSize:28,fontWeight:FontWeight.w900),textAlign:TextAlign.center),
    const SizedBox(height:24), ...options.map((o){final selected=chosen==o; final isRight=o==answer; return Padding(padding:const EdgeInsets.only(bottom:10),child:OutlinedButton(
      style:OutlinedButton.styleFrom(backgroundColor:chosen==null?Colors.white:isRight?Colors.green.shade100:selected?Colors.red.shade100:Colors.white, padding:const EdgeInsets.all(16)),
      onPressed:()=>choose(o), child:Text('$o',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))));}),
    const Spacer(), if(chosen!=null) Text(chosen==answer?'Correct! Keep going.':'Not quite. Correct answer: $answer',textAlign:TextAlign.center,style:TextStyle(fontWeight:FontWeight.bold,color:chosen==answer?Colors.green:Colors.red)),
    const SizedBox(height:12), FilledButton(onPressed:chosen==null?null:(){if(index==9){finish();}else{setState((){index++;_makeQuestion();});}},child:Text(index==9?'View results':'Next question'))
  ])));
}

class ResultPage extends StatelessWidget {
  final String topic; final int correct,wrong,seconds; final List<Map<String,dynamic>> details;
  const ResultPage({super.key,required this.topic,required this.correct,required this.wrong,required this.seconds,required this.details});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Practice report')),body:ListView(padding:const EdgeInsets.all(18),children:[
    Card(child:Padding(padding:const EdgeInsets.all(22),child:Column(children:[Text('$correct / 10',style:const TextStyle(fontSize:38,fontWeight:FontWeight.w900,color:violet)),const Text('Correct answers'),const SizedBox(height:8),Text('Wrong: $wrong  •  Accuracy: ${(correct*10)}%  •  Time: ${seconds}s')]))),
    Text('Question-wise report',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:8),
    ...details.map((d)=>ListTile(leading:Icon(d['ok']?Icons.check_circle:Icons.cancel,color:d['ok']?Colors.green:Colors.red),title:Text(d['q']),subtitle:Text('Your answer: ${d['your']}  •  Correct: ${d['answer']}'))),
    FilledButton(onPressed:()=>Navigator.popUntil(context,(r)=>r.isFirst),child:const Text('Back to home'))
  ]));
}

class ExercisePage extends StatelessWidget {
  final String operation;
  const ExercisePage({super.key,required this.operation});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('$operation Exercise')),body:ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Choose difficulty',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    for(final d in ['Easy','Moderate','Tough']) Card(child:ListTile(title:Text(d),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ExerciseQuiz(operation:operation,difficulty:d)))))
  ]));
}
class ExerciseQuiz extends StatefulWidget {
  final String operation,difficulty;
  const ExerciseQuiz({super.key,required this.operation,required this.difficulty});
  @override State<ExerciseQuiz> createState()=>_ExerciseQuizState();
}
class _ExerciseQuizState extends State<ExerciseQuiz>{
  final rng=Random(); final input=TextEditingController(); int a=0,b=0,index=1,correct=0,wrong=0; String op='+'; int seconds=0; Timer? timer;
  @override void initState(){super.initState();_new();timer=Timer.periodic(const Duration(seconds:1),(_){if(mounted)setState(()=>seconds++);});}
  void _new(){final maxN=widget.difficulty=='Easy'?20:widget.difficulty=='Moderate'?100:500;a=rng.nextInt(maxN)+1;b=rng.nextInt(maxN)+1;final ops=widget.operation=='Mixed'?['+','−','×','÷']:({'Addition':['+'],'Subtraction':['−'],'Multiplication':['×'],'Division':['÷']}[widget.operation]??['+']);op=ops[rng.nextInt(ops.length)];if(op=='÷'){a=a*b;}input.clear();}
  int get answer=>op=='+'?a+b:op=='−'?a-b:op=='×'?a*b:a~/b;
  void submit(){final v=int.tryParse(input.text);if(v==null)return;if(v==answer)correct++;else wrong++;if(index==10){timer?.cancel();Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>ResultPage(topic:'${widget.operation} Exercise',correct:correct,wrong:wrong,seconds:seconds,details:[])));}else{setState((){index++;_new();});}}
  @override void dispose(){timer?.cancel();input.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text('${widget.difficulty} • $seconds s')),body:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    LinearProgressIndicator(value:index/10),const SizedBox(height:28),Text('Question $index of 10',textAlign:TextAlign.center),
    const SizedBox(height:35),Text('$a $op $b = ?',textAlign:TextAlign.center,style:const TextStyle(fontSize:34,fontWeight:FontWeight.w900)),
    const SizedBox(height:28),TextField(controller:input,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Your answer',border:OutlineInputBorder())),
    const Spacer(),FilledButton(onPressed:submit,child:const Text('Submit answer'))
  ])));
}

class ProgressPage extends StatefulWidget { const ProgressPage({super.key}); @override State<ProgressPage> createState()=>_ProgressPageState(); }
class _ProgressPageState extends State<ProgressPage>{
  List<Map<String,dynamic>> history=[];
  @override void initState(){super.initState();_load();}
  Future<void> _load()async{final p=await SharedPreferences.getInstance();final h=p.getStringList('history')??[];if(mounted)setState(()=>history=h.map((e)=>jsonDecode(e) as Map<String,dynamic>).toList().reversed.toList());}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('My Progress')),body:history.isEmpty?const Center(child:Text('No practice completed yet. Start your first test!')):ListView(padding:const EdgeInsets.all(14),children:[
    const Text('Recent practice sessions',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    ...history.map((h)=>Card(child:ListTile(leading:const Icon(Icons.calendar_today,color:violet),title:Text(h['topic']),subtitle:Text('${DateTime.parse(h['date']).toLocal()}'),trailing:Text('${h['correct']}/10',style:const TextStyle(fontWeight:FontWeight.bold)),onTap:()=>showDialog(context:context,builder:(_)=>AlertDialog(title:Text(h['topic']),content:Text('Correct: ${h['correct']}\\nWrong: ${h['wrong']}\\nTime: ${h['seconds']} seconds'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Close'))]))))
  ]));
}
