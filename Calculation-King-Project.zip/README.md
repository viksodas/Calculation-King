# Calculation King

Offline-first Android calculation practice app.

## Build APK with GitHub Actions
1. Upload this project to a GitHub repository on the `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and tap **Run workflow** (or push a commit).
4. Open the completed workflow run and download the `calculation-king-apk` artifact.
5. Extract the ZIP and install `app-release.apk` on your Android phone.

This is an initial working build. It includes the home screen, learning/practice entry points, timed practice, typed arithmetic exercises, and locally saved session history. Further rounds will refine conversion question logic, per-question timing, calendar/date grouping, and detailed exercise reports.
